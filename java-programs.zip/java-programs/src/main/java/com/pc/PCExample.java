package com.pc;

public class PCExample {
    public static void main(String[] args) {
        SharedBuffer sharedBuffer = new SharedBuffer();
        // create producer and consumer threads
        Thread producerThread = new Thread(new Producer(sharedBuffer));
        Thread consumerThread = new Thread(new Consumer(sharedBuffer));

        // start the threads
        producerThread.start();
        consumerThread.start();
    }
}
