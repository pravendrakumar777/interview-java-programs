package com.pc;

import java.util.LinkedList;
import java.util.Queue;

public class SharedBuffer {

    private Queue<Integer> buffer = new LinkedList<>();
    private final int capacity = 10; // buffer size

    // 1. method to add data to the buffer (Producer)
    public synchronized void produce(int value) throws InterruptedException {
        while (buffer.size() == capacity) {
            // Wait until the buffer has space
            wait();
        }
        buffer.add(value);
        System.out.println("Produced: " + value);
        notify(); // notify consumer that there is data to consume
    }

    // 2. method to consume data from the buffer (Consumer)
    public synchronized int consume() throws InterruptedException {
        while (buffer.isEmpty()) {
            // Wait until there is data to consume
            wait();
        }
        int value = buffer.poll();
        System.out.println("Consumed: " + value);
        notify();
        return value;
    }
}
