package com.pc;

public class Consumer implements Runnable {

    private final SharedBuffer buffer;

    public Consumer(SharedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            for (int i=0; i<=20; i++) {
                buffer.consume();
                Thread.sleep(150); // Simulating time taken to consume data
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
}
