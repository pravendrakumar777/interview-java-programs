package com.expression;

public interface Adder {
    int sub(int a, int b);
}
