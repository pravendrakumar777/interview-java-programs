package com.Array2D;

public class ManipulationOfArray {

        public static void main(String[] args) {

            int N = 5; // Size of the array
            int M = 3; // Number of queries

            // Each row = {A, B, V}
            int[][] queries = {
                    {1, 2, 100},
                    {2, 5, 100},
                    {3, 4, 100}
            };

            // === HARD-CODED INPUT END ===

            long[] diff = new long[N + 2]; // Difference array

            // Apply queries using difference array
            for (int i = 0; i < M; i++) {
                int A = queries[i][0];
                int B = queries[i][1];
                int V = queries[i][2];

                diff[A] += V;
                if (B + 1 <= N) {
                    diff[B + 1] -= V;
                }
            }

            // Build final array with prefix sum and find max
            long maxVal = 0;
            long current = 0;

            for (int i = 1; i <= N; i++) {
                current += diff[i];
                if (current > maxVal) {
                    maxVal = current;
                }
            }

            // Output the result
            System.out.println(maxVal);
        }
    }

