package com.diamond;

public class D implements B, C {

    @Override
    public void hello() {
        B.super.hello();
    }
}
