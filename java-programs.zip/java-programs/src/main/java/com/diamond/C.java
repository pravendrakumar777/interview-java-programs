package com.diamond;

public interface C extends A{
    default void hello() {
        System.out.println("Hello from C");
    }
}
