package com.generics;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class TestGenericMethod {

    // generic type of method that accept any kind of data types
    public static <T> void printArray(T[] array) {
        for (T element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Integer[] intArray = {1, 2, 3, 4};
        String[] strArray = {"A", "B", "C"};
        Character[] ch = {'a', 'b', 'c', 'd'};

        printArray(intArray);
        printArray(strArray);
        printArray(ch);
    }
    static class SecondLargest {
        public static <T extends Comparable<T>> T secondLargest(T[] arr, int total) {
            T temp;

            for (int i = 0; i < arr.length; i++) {
                for (int j = i + 1; j < arr.length; j++) {
                    if (arr[i].compareTo(arr[j]) > 0) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 2];
        }

        public static void main(String[] args) {
            Integer[] arr = {3, 5, 1, 9, 7};
            System.out.println("Second largest (Integer): " + secondLargest(arr, arr.length));

            String[] strArray = {"apple", "banana", "cherry", "date"};
            System.out.println("Second largest (String): " + secondLargest(strArray, strArray.length));
        }
    }

    static class SecondSmallest {
        public static <T extends Comparable<T>> T secondSmallest(T[] arr, int total) {
            T temp;

            for (int i = 0; i < arr.length; i++) {
                for (int j = i + 1; j < arr.length; j++) {
                    if (arr[i].compareTo(arr[j]) < 0) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 2];
        }

            public static void main(String[] args) {
                Integer[] arr = {3, 5, 1, 9, 2, 7};
                System.out.println("Second largest (Integer): " + secondSmallest(arr, arr.length));

                String[] strArray = {"apple", "banana", "cherry", "date"};
                System.out.println("Second largest (String): " + secondSmallest(strArray, strArray.length));
            }
    }

    static class RemoveDuplicate {
        public static <T> T[] removeDuplicate(T[] arr) {
            Set<T> set = new LinkedHashSet<>(Arrays.asList(arr));
            T[] result = Arrays.copyOf(arr, set.size());

            int i = 0;
            for (T item : set) {
                result[i++] = item;
            }
            return result;
        }

        public static void main(String[] args) {
            Integer[] nums = {1, 2, 2, 3, 4, 4, 5};
            Integer[] removeDup = removeDuplicate(nums);
            System.out.println("Unique Arrays : " + Arrays.toString(removeDup));

            String[] words = {"apple", "banana", "apple", "orange"};
            String[] uniqueWords = removeDuplicate(words);
            System.out.println("Unique Strings : " + Arrays.toString(uniqueWords));
        }
    }

    static class FindDuplicates {
        public static <T> Set<T> findDuplicates(T[] arr) {
            Set<T> set = new HashSet<>();
            Set<T> duplicates = new HashSet<>();

            for (T item : arr) {
                if (!set.add(item)) {
                    duplicates.add(item);
                }
            }
            return duplicates;
        }

        public static void main(String[] args) {
            String[] words = {"apple", "banana", "apple", "orange", "banana"};
            System.out.println("Duplicates (String): " + findDuplicates(words));

            Integer[] nums = {1, 2, 3, 2, 4, 1, 5};
            System.out.println("Duplicates (Integer): " + findDuplicates(nums));
        }
    }
}
