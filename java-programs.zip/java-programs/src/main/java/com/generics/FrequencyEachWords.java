package com.generics;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FrequencyEachWords {
    public static void main(String[] args) {

        List<String> list = Arrays.asList("Java", "Python", "C#", "Java", "Kotlin", "Python");

        // frequency for each words
        Map<String, Long> freq = list.stream().collect(Collectors.groupingBy(word -> word, Collectors.counting()));

        freq.forEach((word, count) ->
                        System.out.println(word + " : " + count)
                );

        // unique
        System.out.println("===============");
        System.out.println("Unique Words: ");
        freq.entrySet().stream()
                .filter(entry -> entry.getValue() == 1)
                .forEach(entry -> System.out.println(entry.getKey()));

    }
}
