package com.practice;

import java.util.Scanner;

public class ReversArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] a = new int[10];

        System.out.println("Enter the numbers:");

        for (int i = 0; i <= 5; i++) {
            a[i] = scanner.nextInt();
        }

        System.out.println("Your Array:");

        for (int i = 5; i >= 0; i--) {
            System.out.println(a[i]);
        }

    }
}
