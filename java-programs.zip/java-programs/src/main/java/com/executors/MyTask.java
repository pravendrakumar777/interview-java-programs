package com.executors;

public class MyTask implements Runnable {
    private String taskName;

    public MyTask(String taskName) {
        this.taskName = taskName;
    }

    @Override
    public void run() {
        try {
            System.out.println("Task " + taskName + "is running on " + Thread.currentThread().getName());
            Thread.sleep(1000);
            System.out.println("Task " + taskName + "is completed on " + Thread.currentThread().getName());
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
}
