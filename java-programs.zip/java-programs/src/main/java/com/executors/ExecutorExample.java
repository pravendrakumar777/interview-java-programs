package com.executors;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorExample {
    public static void main(String[] args) {

        // create fixed thread pool with 3 threads
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        // submit multiple tasks
        for (int i=0; i<=5; i++) {
            executorService.submit(new MyTask("Task-" + i + " "));
        }
        executorService.shutdown();

        try {
            // Wait until all tasks are finished
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdown();
            }
        } catch (InterruptedException ex) {
            executorService.shutdown();
        }
        System.out.println("All tasks are completed.");
    }
}
