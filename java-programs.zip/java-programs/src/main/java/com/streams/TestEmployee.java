package com.streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestEmployee {
    public static void main(String[] args) {

        List<Employee> employees = Arrays.asList(
                new Employee("Alice", "IT", 70000),
                new Employee("Bob", "HR", 50000),
                new Employee("Charlie", "IT", 80000),
                new Employee("David", "Finance", 75000),
                new Employee("Eve", "HR", 52000),
                new Employee("Frank", "Finance", 77000)
        );

        // fetch salary of employee with department
        Map<String, List<Double>> departSalaries = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, Collectors.mapping(Employee::getSalary, Collectors.toList())));

        departSalaries.forEach((department, salary) ->
                        System.out.println(department + " Salaries: " + salary));
    }
}
