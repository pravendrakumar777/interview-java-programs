package com.inter;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SecondHighestNumber {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 3, 8, 9, 1, 10, 10);

        Integer second = list.stream().distinct()
                .sorted(Comparator.reverseOrder())
                .skip(1)
                .findFirst()
                .orElse(null);

        System.out.println("Second Highest Number: " + second);
    }


    static class FoundWordFrequency {
        public static void main(String[] args) {
            List<String> words = Arrays.asList("apple", "banana", "apple", "orange", "banana", "apple");

            Map<String, Long> count = words.stream().collect(Collectors.groupingBy(word -> word, Collectors.counting()));
            List<Map.Entry<String, Long>> topThree = count.entrySet().stream()
                    .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder()))
                    .limit(3)
                    .collect(Collectors.toList());

            topThree.forEach(e ->
                            System.out.println(e.getKey() + " : " + e.getValue())
                    );
        }
    }
}
