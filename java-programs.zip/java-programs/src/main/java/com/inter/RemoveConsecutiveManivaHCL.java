package com.inter;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RemoveConsecutiveManivaHCL {
    public static void main(String[] args) {
        String input = "HEEELLOOMooanndaay";
        //String output = "HELLOMonnday";

        String output = removeVowels(input);
        System.out.println("Output: " + output);
    }

    public static String removeVowels(String input) {
        List<Character> chars = input.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
        StringBuilder sb = new StringBuilder();
        IntStream.range(0, chars.size()).filter(i -> {
                    char cu = chars.get(i);
                    if (i == 0) return true;
                    char pr = chars.get(i - 1);
                    return !(isVowel(cu) && isVowel(pr));
                })
                .forEach(i -> sb.append(chars.get(i)));
        return sb.toString();
    }

    private static boolean isVowel(char ch) {
        return "aeiouAEIOU".indexOf(ch) != -1;
    }
}
