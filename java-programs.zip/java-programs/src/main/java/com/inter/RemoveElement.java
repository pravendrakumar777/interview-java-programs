package com.inter;

public class RemoveElement {
    public static void main(String[] args) {
        int[] num1 = {3, 2, 2, 3};
        int val1 = 3;
        int k1 = removeElement(num1, val1);

        System.out.println("Output: " + k1);
        System.out.print("nums = [");
        for (int i = 0; i < k1; i++) {
            System.out.print(num1[i]);
            if(i < k1 - 1)
                System.out.print(", ");
        }
        System.out.println("]");

        int[] num2 = {0, 1, 2, 2, 3, 0, 4, 2};
        int val2 = 2;
        int k2 = removeElement(num2, val2);

        System.out.println("Output: " + k2);
        System.out.print("nums = [");
        for (int j = 0;j < k2; j++) {
            System.out.print(num2[j]);
            if (j < k2 - 1)
                System.out.print(", ");
        }
        System.out.println("]");
    }

    public static int removeElement(int[] nums, int val) {
        int k = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[k] = nums[i];
                k++;
            }
        }
        return k;
    }
}
