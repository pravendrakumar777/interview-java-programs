package com.starpattern;

public class MiddleTriangle {
    public static void main(String arg []){

    }
}
