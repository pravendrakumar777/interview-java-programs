package com.starpattern;

public class LeftTriangle {
    public static void main(String args[]){
        int length = 5;
        for(int i = 0; i < length; i++) {
            for (int j = length; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 0; k < i; k++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
