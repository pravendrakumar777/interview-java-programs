package com.starpattern;


public class RightTriangle {
    public static void main(String args[]){
        int length = 5;

        for(int i = 1; i < length; i++){
            for(int j = 1; j <= i; j++){
                System.out.print(" * ");
            }
            System.out.println(" ");
        }
    }
}
