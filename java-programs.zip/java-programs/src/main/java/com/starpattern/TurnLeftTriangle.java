package com.starpattern;

public class TurnLeftTriangle {

}
