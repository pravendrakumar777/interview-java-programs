package com.numbersystem;

import java.util.*;

public class ShortWordsToNumber {
    private static final Map<String, Integer> words = Map.ofEntries(
            Map.entry("one", 1), Map.entry("two", 2), Map.entry("three", 3),
            Map.entry("four", 4), Map.entry("five", 5), Map.entry("six", 6),
            Map.entry("seven", 7), Map.entry("eight", 8), Map.entry("nine", 9),
            Map.entry("ten", 10), Map.entry("twenty", 20), Map.entry("thirty", 30),
            Map.entry("forty", 40), Map.entry("fifty", 50), Map.entry("hundred", 100),
            Map.entry("thousand", 1000), Map.entry("million", 1_000_000),
            Map.entry("billion", 1_000_000_000)
    );

    public static long convert(String input) {
        String[] parts = input.toLowerCase().split(" ");
        long total = 0;
        long temp = 0;

        for (String part : parts) {
            if (words.containsKey(part)) {
                int val = words.get(part);
                if (val == 100) {
                    temp = temp * val;
                } else if (val >= 1000) {
                    temp = temp * val;
                    total = total + temp;
                    temp = 0;
                } else {
                    temp = temp + val;
                }
            }
        }
        return total + temp;
    }

    public static void main(String[] args) {
        String input = "three hundred million";
        System.out.printf("Input: %s\nOutput: %,d\n", input, convert(input));
    }
}
