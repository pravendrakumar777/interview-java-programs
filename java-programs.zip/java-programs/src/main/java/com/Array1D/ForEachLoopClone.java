package com.Array1D;

public class ForEachLoopClone {
    public static void main(String arg []){
        int arr[] = {1,2,3,4,5,6,7,8,9};
        for(int i:arr)
            System.out.println(i);

           System.out.println("The Array is Clone");

           int car[] = arr.clone();
           for(int i:car)
               System.out.println(i);

           System.out.println(arr==car);
    }
}