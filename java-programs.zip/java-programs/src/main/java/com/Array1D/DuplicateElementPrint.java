package com.Array1D;

public class DuplicateElementPrint {
    public static void main(String arg[]) {
        int arr[] = {17, 2, 33, 4, 5, 6, 77, 8, 33, 5, 17};
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    System.out.print(arr[i] + " ");
                }
            }
        }
    }
}
