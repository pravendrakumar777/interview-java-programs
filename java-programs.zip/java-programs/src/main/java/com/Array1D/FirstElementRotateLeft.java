package com.Array1D;

public class FirstElementRotateLeft {
    public static void main(String[] args) {
        int arr[] = {1, 2, 3, 4, 5};  // Original array
        int n = 2;  // Number of left rotations

        // Displaying the original array
        System.out.print("Original array: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

        // Performing left rotations
        for (int i = 0; i < n; i++) {
            // Store the first element temporarily
            int first = arr[0];

            // Shift all elements to the left
            for (int j = 0; j < arr.length - 1; j++) {
                arr[j] = arr[j + 1];
            }

            // Put the first element at the end
            arr[arr.length - 1] = first;
        }

        // Displaying the array after left rotations
        System.out.print("Array after " + n + " left rotations: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
