package com.singleton;

public class SingletonDoubleCheckedLocking {

    // Declare the instance variable
    private static volatile SingletonDoubleCheckedLocking instance;

    // Private constructor to prevent instantiation
    private SingletonDoubleCheckedLocking() {}

    // Provide a global point of access to the instance (thread-safe)
    public static SingletonDoubleCheckedLocking getInstance() {
        // First check (without synchronization)
        if (instance == null) {
            // Second check (with synchronization)
            synchronized (SingletonDoubleCheckedLocking.class) {
                if (instance == null) {
                    instance = new SingletonDoubleCheckedLocking(); // create instance if not created yet
                }
            }
        }
        return instance;
    }
}
