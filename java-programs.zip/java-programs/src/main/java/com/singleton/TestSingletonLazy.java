package com.singleton;

public class TestSingletonLazy {
    public static void main(String[] args) {

        // Access the singleton instance
        SingletonLazy singleton1 = SingletonLazy.getInstance();
        SingletonLazy singleton2 = SingletonLazy.getInstance();

        System.out.println(singleton1.hashCode());
        System.out.println(singleton2.hashCode());
    }
}
