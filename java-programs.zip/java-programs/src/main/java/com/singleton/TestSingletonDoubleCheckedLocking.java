package com.singleton;

public class TestSingletonDoubleCheckedLocking {
    public static void main(String[] args) {

        // Access the singleton instance
        SingletonDoubleCheckedLocking singleton1 = SingletonDoubleCheckedLocking.getInstance();
        SingletonDoubleCheckedLocking singleton2 = SingletonDoubleCheckedLocking.getInstance();

        System.out.println(singleton1.hashCode());
        System.out.println(singleton2.hashCode());
    }
}
