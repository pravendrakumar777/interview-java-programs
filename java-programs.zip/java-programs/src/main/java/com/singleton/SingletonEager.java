package com.singleton;

public class SingletonEager {

    // create a single instance at the time of class loading
    private static final SingletonEager instance = new SingletonEager();

    // Private constructor to prevent instantiation
    private SingletonEager() {}

    // public global point of access to the instance
    public static SingletonEager getInstance() {
        return instance;
    }
}