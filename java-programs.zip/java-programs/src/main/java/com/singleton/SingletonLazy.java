package com.singleton;

public class SingletonLazy {
    // Declare the instance variable but do not initialize it
    private static SingletonLazy instance;
    // Private constructor to prevent instantiation
    private SingletonLazy() {}

    // global point of access to the instance (not thread-safe)
    public static SingletonLazy getInstance() {
        if (instance == null) {
            instance = new SingletonLazy();
        }
        return instance;
    }
}
