package com.singleton;

public class TestSingletonEager {
    public static void main(String[] args) {
        // Access the singleton instance
        SingletonEager singleton1 = SingletonEager.getInstance();
        SingletonEager singleton2 = SingletonEager.getInstance();


        System.out.println(singleton1.hashCode());
        System.out.println(singleton2.hashCode());
    }
}
