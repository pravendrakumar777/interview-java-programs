package com.concurrency;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierExample {
    public static void main(String[] args) {
        int threadCount = 3;
        CyclicBarrier barrier = new CyclicBarrier(threadCount, () -> {
            System.out.println("All threads reached the barrier. Continuing together...");
        });

        for (int i = 1; i <= threadCount; i++) {
            new Thread(() -> {
                System.out.println(Thread.currentThread().getName() + " is working...");
                try {
                    Thread.sleep((int) (Math.random() * 2000));
                    System.out.println(Thread.currentThread().getName() + " waiting at barrier.");
                    barrier.await();
                    System.out.println(Thread.currentThread().getName() + " passed the barrier.");
                } catch (InterruptedException | BrokenBarrierException ex) {
                    ex.printStackTrace();
                }
            }, "Thread-" + i).start();
        }
    }
}
