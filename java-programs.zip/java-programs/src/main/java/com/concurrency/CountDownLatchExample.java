package com.concurrency;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {
    public static void main(String[] args) throws InterruptedException {
        int workerCount = 3;
        CountDownLatch latch = new CountDownLatch(workerCount);

        for (int i = 1; i <= workerCount; i++) {
            new Thread(() -> {
                System.out.println(Thread.currentThread().getName() + " working...");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                System.out.println(Thread.currentThread().getName() + " finished.");
                latch.countDown();
            }, "Worker-" + i).start();
        }
        System.out.println("Main thread waiting for workers...");
        latch.await();
        System.out.println("All workers completed. Main thread proceeding.");
    }
}
