package com.serialization;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SerializeExample {
    public static void main(String[] args) {

        Student student = new Student("Pravendra", 27);

        try(FileOutputStream fileOutput = new FileOutputStream("student.ser");
            ObjectOutputStream outputStream = new ObjectOutputStream(fileOutput)) {

            outputStream.writeObject(student);
            System.out.println("Object has been serialized to student.ser");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
