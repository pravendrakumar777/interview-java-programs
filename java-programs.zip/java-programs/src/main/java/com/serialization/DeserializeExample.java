package com.serialization;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializeExample {
    public static void main(String[] args) {

        try(FileInputStream fileInput = new FileInputStream("student.ser");
            ObjectInputStream objectInput = new ObjectInputStream(fileInput)) {

            Student student = (Student) objectInput.readObject();
            System.out.println("Object has been deserialized:");
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
