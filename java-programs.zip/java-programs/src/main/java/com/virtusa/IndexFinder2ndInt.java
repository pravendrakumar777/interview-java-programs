package com.virtusa;

public class IndexFinder2ndInt {
    public static int indexFinder(int[] nums) {
        if (nums == null || nums.length == 0)
            return -1;

        int maxIndex = 0;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] > nums[maxIndex]) {
                maxIndex = i;
            }
        }
        for (int i =0; i < nums.length; i++) {
            if (i != maxIndex && nums[maxIndex] < 2 * nums[i]) {
                return -1;
            }
        }
        return maxIndex;
    }

    public static void main(String[] args) {
        int[] num1 = {3, 6, 1, 0};
        int[] num2 = {1, 2, 3, 4};

        System.out.println("Output for num1 array: " + indexFinder(num1));
        System.out.println("Output for num2 array: " + indexFinder(num2));
    }
}
