package com.virtusa;

import java.util.HashMap;
import java.util.Map;

public class EachCharacterFrequency1stInt {
    public static void main(String[] args) {

        String str = "java is a programming language";
        // find each character count without any collection

        str = str.replaceAll(" ", "");

        int [] count = new int[256];

        for (int i =0; i < str.length(); i++) {
            count[str.charAt(i)]++;
        }
        for (int i=0; i<256; i++) {
            if (count[i] > 0) {
                System.out.println((char) i + " :: " + count[i]);
            }
        }
    }

    static class TestClassUsingCollection {
        public static void main(String[] args) {

            String str = "java is a programming language";
            str = str.replaceAll(" ", "");

            Map<Character, Integer> charCountMap = new HashMap<>();

            for (char c : str.toCharArray()) {
                if (charCountMap.containsKey(c)) {
                    charCountMap.put(c, charCountMap.get(c) + 1);
                } else {
                    charCountMap.put(c, 1);
                }
            }

            for (Map.Entry<Character, Integer> entry : charCountMap.entrySet()) {
                System.out.println(entry.getKey() + " :: " + entry.getValue());
            }
        }
    }
}
