package com.virtusa;

import java.util.Stack;

public class BalancedBrackets3rdInt {
    public static boolean isBalanced(String str) {
        Stack<Character> stack = new Stack<>();
        for (char ch : str.toCharArray()) {
            if (ch == '(' || ch == '{' || ch == '[') {
                stack.push(ch);
            } else if (ch == ')' || ch == '}' || ch == ']'){
                if (stack.isEmpty()) {
                    return false;
                }
                char tp = stack.pop();
                if (!matchPair(tp, ch)) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    private static boolean matchPair(char op, char cl) {
        return (op == '(' && cl == ')') || (op == '{' && cl == '}') || (op == '[' && cl == ']');
    }

    public static void main(String[] args) {
        String str1 = "(())";
        String str2 = "([{]})";

        System.out.println("Example1: " + str1 + "  " + isBalanced(str1));
        System.out.println("Example2: " + str2 + "  " + isBalanced(str2));
    }
}
