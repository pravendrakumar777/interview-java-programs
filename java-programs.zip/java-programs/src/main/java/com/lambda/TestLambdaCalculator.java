package com.lambda;

public class TestLambdaCalculator {
    public static void main(String[] args) {

        System.out.println("Addition : " + CalculatorOperation.addition(10, 5));
        System.out.println("Subtraction : " + CalculatorOperation.subtract(10, 5));
        System.out.println("Multiplication : " + CalculatorOperation.multiply(10, 5));
        System.out.println("Division : " + CalculatorOperation.divide(10, 5));
        System.out.println("Modulus : " + CalculatorOperation.modulus(10, 3));
    }
}
