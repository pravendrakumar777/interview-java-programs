package com.lambda;
public interface CalculatorOperation {

    // functional interface
    double operation(double a, double b);

    static double addition(double a, double b) {
        CalculatorOperation op = (x, y) -> x + y;
        return op.operation(a, b);
    }

    static double subtract(double a, double b) {
        CalculatorOperation op = (x, y) -> x - y;
        return op.operation(a, b);
    }

    static double multiply(double a, double b) {
        CalculatorOperation op = (x, y) -> x * y;
        return op.operation(a, b);
    }

    static double divide(double a, double b) {
        CalculatorOperation op = (x, y) -> y != 0 ? x / y : Double.NaN;
        return op.operation(a, b);
    }

    static double modulus(double a, double b) {
        CalculatorOperation op = (x, y) -> x % y;
        return op.operation(a, b);
    }
}
