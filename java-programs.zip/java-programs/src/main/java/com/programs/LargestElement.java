package com.programs;

public class LargestElement {
    public static void main(String[] args) {
        int arr[] = {23, 45, 33, 55, 67, 88, 22, 21};
        int max = arr[0];

        for (int i=0; i<arr.length; i++) {
            if (arr[i] > max)
                max = arr[i];
        }
        System.out.println("Largest Element: " + max);
    }

    static class Largest{
        public static void main(String[] args) {
            int arr[] = {12, 33, 4444, 5555, 77777};
            int max = arr[0];

            for (int i=0; i<arr.length; i++) {
                if (arr[i] > max)
                    max = arr[i];
            }
            System.out.println("Max: " + max);
        }
    }

    static class MIN{
        public static void main(String[] args) {
            int arr[] = {12, 34, 55, 5, 678};
            int min = arr[0];

            for (int i=0; i<arr.length; i++) {
                if (arr[i] < min)
                    min = arr[i];
            }
            System.out.println("Min: " + min);
        }
    }
}
