package com.programs;

public class SecondSmallest {
    public static int secondSmallest(int arr[], int total) {
        int temp;

        for (int i=0; i<total; i++) {
            for (int j=i+1; j<total; j++) {
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        return arr[total-2];
    }

    public static void main(String[] args) {
        int arr[] = {234, 456, 678, 800, 890};
        System.out.println("Second Smallest: " + secondSmallest(arr, arr.length));
    }
}
