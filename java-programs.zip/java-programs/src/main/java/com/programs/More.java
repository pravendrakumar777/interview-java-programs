package com.programs;

public class More {
    public static void main(String[] args) {

    }

    static class StringExample {
        public static void main(String[] args) {
            String str = "abc";
            System.out.println(str.hashCode());

            str = str + "xyz";
            System.out.println(str.hashCode());
            System.out.println(str);
        }
    }
}
