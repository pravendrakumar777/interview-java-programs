package com.programs;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamOperations {
    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);

        // find even
        numbers.stream().filter(num -> num % 2 == 0).forEach(System.out::println);

        // find even and store into another list
        List<Integer> evenNum = numbers.stream().filter(num -> num %2 == 0).collect(Collectors.toList());
        System.out.println(evenNum);

        // odd
        List<Integer> oddNumber = numbers.stream().filter(num -> num % 2 != 0).collect(Collectors.toList());
        System.out.println(oddNumber);

        // sum
        int sumNumber = numbers.stream().mapToInt(Integer::intValue).sum();
        System.out.println(sumNumber);

        // max num
        int max = numbers.stream().max(Integer::compare).orElseThrow(() -> new IllegalArgumentException("Empty List"));
        System.out.println(max);

        // min num
        int min = numbers.stream().min(Integer::compare).orElseThrow(() -> new IllegalArgumentException("Empty List"));
        System.out.println(min);

        // square of each number
        List<Integer> squareOfEach = numbers.stream().map(num -> num * num).collect(Collectors.toList());
        System.out.println(squareOfEach);

        // convert List into Set
        Set<Integer> set = numbers.stream().collect(Collectors.toSet());
        System.out.println(set);

        // convert into Map
        Map<Integer, Integer> map = numbers.stream().collect(Collectors.toMap(numbers::indexOf, n -> n));
        System.out.println(map);

        //
    }
}
