package com.programs;

public class ThirdSmallest {
    public static int thirdSmallest(int arr[], int total) {
        int temp;

        for (int i=0; i<total; i++) {
            for (int j=i+1; j<total; j++) {
                if (arr[i]<arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
        return arr[total - 3];
    }

    public static void main(String[] args) {
        int arr[] = {12, 45, 67, 78, 777, 888, 999, 1000};
        System.out.println("Third Smallest: " + thirdSmallest(arr, arr.length));

    }
}
