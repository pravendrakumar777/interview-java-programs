package com.programs.sapient;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.IntStream;

public class MaxProfitFinder {

    /*
    Write a java program to find the max profit based on the given prices and the given Money.
    For this example, the best buy price should be 8 and sell price should be 155
    Money = 20; Prices = [23, 230, 16, 24, 35, 80, 70, 18, 29, 150, 8, 155, 17];
     */
    public static void main(String[] args) {

        int[] prices = {23, 230, 16, 24, 35, 80, 70, 18, 29, 150, 8, 155, 17};
        int money = 20;

        int maxProfit = 0;
        int bestBy = -1;
        int bestSell = -1;

        for (int i = 0; i < prices.length; i++) {
            if (prices[i] <= money) {
                for (int j = i+1; j < prices.length; j++) {
                    int profit = prices[j] - prices[i];
                    if (profit > maxProfit) {
                        maxProfit = profit;
                        bestBy = prices[i];
                        bestSell = prices[j];
                    }
                }
            }
        }
        if (maxProfit > 0) {
            System.out.println("Best Buy Price: " + bestBy);
            System.out.println("Best Sell Price: " + bestSell);
            System.out.println("Max Profit: " + maxProfit);
        } else {
            System.out.println("No profitable transaction possible with the given money.");
        }
    }

    static class MaxProfitWithStreams {
        public static void main(String[] args) {
            int[] prices = {23, 230, 16, 24, 35, 80, 70, 18, 29, 150, 8, 155, 17};
            int money = 20;
            class Transaction {
                int buy;
                int sell;
                int profit;

                public Transaction(int buy, int sell) {
                    this.buy = buy;
                    this.sell = sell;
                    this.profit = sell - buy;
                }
            }

            Optional<Transaction> maxTransaction = IntStream.range(0, prices.length)
                    .filter(i -> prices[i] <= money)
                    .boxed()
                    .flatMap(i -> IntStream.range(i + 1, prices.length)
                            .mapToObj(j -> new Transaction(prices[i], prices[j]))
                    )
                    .max(Comparator.comparingInt(t -> t.profit));

            if (maxTransaction.isPresent()) {
                Transaction t = maxTransaction.get();
                System.out.println("Best Buy Price: " + t.buy);
                System.out.println("Best Sell Price: " + t.sell);
                System.out.println("Max Profit: " + t.profit);
            } else {
                System.out.println("No profitable transaction possible with the given money.");
            }
        }
    }
}
