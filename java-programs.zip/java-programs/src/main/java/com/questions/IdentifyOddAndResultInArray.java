package com.questions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IdentifyOddAndResultInArray {
    public static void main(String[] args) {
        int[][] arr = {
                {3, 0, 1},
                {2, 0, 1},
                {3, 2, 1}
        };

        int [] result = Arrays.stream(arr)
                .flatMapToInt(Arrays::stream)
                .filter(num -> num % 2 != 0)
                .map(n -> n * 2)
                .toArray();
        System.out.println("Result: " + Arrays.toString(result));


        List<Integer> resultList = new ArrayList<>();
        for (int i=0; i < arr.length; i++) {
            for (int j=0; j<arr.length; j++) {
                int value = arr[i][j];
                if (value  % 2 != 0) {
                    resultList.add(value*2);
                }
            }
        }

        int [] results = new int[resultList.size()];
        for (int i=0; i<resultList.size(); i++) {
            results[i] = resultList.get(i);
        }

        System.out.print("Result: ");
        for (int num : results) {
            System.out.print(num + " ");
        }
    }
}
