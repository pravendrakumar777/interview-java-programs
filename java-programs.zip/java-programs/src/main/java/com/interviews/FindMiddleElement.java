package com.interviews;

import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class FindMiddleElement {
    public static Node findMiddleElement(Node head) {
        Node nd = head;
        Node fst = head;

        while (fst != null && fst.next != null) {
            nd = nd.next;
            fst = fst.next.next;
        }
        return nd;
    }
    public static void main(String[] args) {

        Node head = new Node(10);
        head.next = new Node(20);
        head.next.next = new Node(30);
        head.next.next.next = new Node(40);
        head.next.next.next.next = new Node(50);
        head.next.next.next.next.next = new Node(60);

        Node middleElement = findMiddleElement(head);
        System.out.println("Middle Element: " + middleElement.data);
    }

    static class ThirdLargestElement {
        public static int thirdLargest(int arr[], int total) {
            int temp;

            for (int i=0; i<arr.length;i++) {
                for (int j=i+1; j<arr.length; j++) {
                    if (arr[i] > arr[j]) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 3];
        }
        public static void main(String[] args) {
            int arr[] = {40,50,70,10,100,50,20};
            System.out.println("Third Largest Element : " + thirdLargest(arr, arr.length));
        }
    }

    static class ThirdLargestPriority {
        public static Integer thirdLargest(int arr[]) {
            Set<Integer> unique = new HashSet<>();

            PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

            for (int num : arr) {
                if (unique.add(num)) {
                    priorityQueue.offer(num);
                    if (priorityQueue.size() > 3) {
                        priorityQueue.poll();
                    }
                }
            }
            return priorityQueue.size() == 3 ? priorityQueue.peek() : null;
        }
        public static void main(String[] args) {
            int arr[] = {40,50,70,10,100,50,20};
            System.out.println("Third Largest Element : " + thirdLargest(arr));

        }
    }
}
