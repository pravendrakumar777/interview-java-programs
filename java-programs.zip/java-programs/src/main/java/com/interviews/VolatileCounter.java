package com.interviews;

public class VolatileCounter {
    private static volatile int counter = 0;

    public static void main(String[] args) {

        // thread - increments the counter
        Thread writer = new Thread(() -> {
            for (int i=1; i<=5; i++) {
                counter = i;
                System.out.println("Writer counter: " + counter);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // thread - reads the counter
        Thread reader = new Thread(() -> {
            int lastRead = -1;
            while (counter < 5) {
                if (lastRead != counter) {
                    System.out.println("Reader counter: " + counter);
                    lastRead = counter;
                }
            }
        });

        writer.start();
        reader.start();
    }
}
