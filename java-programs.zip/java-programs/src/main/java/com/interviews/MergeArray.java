package com.interviews;

import java.util.Arrays;
import java.util.stream.Stream;

public class MergeArray {
    public static void main(String[] args) {
        Integer[] arr1={3,5,2,10,12};
        Integer[] arr2={11,7,8,9,34};

        Integer [] mergedArray = Stream
                .concat(Arrays.stream(arr1),
                        Arrays.stream(arr2))
                .toArray(Integer[]::new);

        System.out.println(Arrays.toString(mergedArray));
    }
}
