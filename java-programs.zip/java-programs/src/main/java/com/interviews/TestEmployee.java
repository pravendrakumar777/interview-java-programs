package com.interviews;

import java.util.*;

public class TestEmployee {
    public static void main(String[] args) {

        List<Employee> employees = Arrays.asList(
                new Employee("Ajay", "Development", 45678),
                new Employee("Ratan", "Production", 20000),
                new Employee("Yog", "QA", 55000),
                new Employee("Dharam", "Staging", 12000),
                new Employee("Pravendra", "Support", 25000)
        );

        // find second highest salary employees
        TreeSet<Double> salary = new TreeSet<>(Collections.reverseOrder());
        for (Employee emp : employees) {
            salary.add(emp.getSalary());
        }

        if (salary.size() < 2 ) {
            System.out.println("There is no second highest salary");
        }
        else {
            Iterator<Double> iterator = salary.iterator();
            iterator.next();

            double secondHighest = iterator.next();
            System.out.println("Second Highest salary: " + secondHighest);
        }

        // using stream api
        Optional<Double> secondHighestSalary = employees.stream()
                .map(Employee::getSalary)
                .distinct()
                .sorted(Comparator.reverseOrder())
                .skip(1)
                .findFirst();

        if (secondHighestSalary.isPresent()) {
            System.out.println("Second Highest Salary: " + secondHighestSalary);
        } else {
            System.out.println("There is no second highest Salary");
        }
    }
}
