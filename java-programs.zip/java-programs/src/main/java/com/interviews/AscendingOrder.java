package com.interviews;

public class AscendingOrder {
    public static void main(String[] args) {
        int[] arr = {78, 34, 1, 3, 90, 34, 6, 55, 20};
        int temp;

        System.out.println("Ascending order: ");
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] > arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
            System.out.print(arr[i] + " ");
        }
    }

    static public class Exception {

        public static void main(String[] args) {

            //    String str = null;

            //    System.out.println(str.length());


            try {

                int a = 80;

                int b = 0;

                int c = a / b;

                System.out.println(c);

            } catch (ArithmeticException e) {
                System.out.println("Can't divide by zero.."); // Arithmetic Exception
            }

            try {

                int num = Integer.parseInt("Sunglowsys");
                System.out.println(num);
            } catch (NumberFormatException e) {
                System.out.println("Number Format Exception.."); // Number Format Exception
            }

            try {
                int arr[] = new int[5];
                arr[7] = 9;
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Array Index OutOfBound Exception..");
            }
            System.exit(0);

        }
    }
}
