package com.interviews;

public class CustomException {
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 10) throw new InvalidAgeException("Age must be 18 or above.");
    }
}
