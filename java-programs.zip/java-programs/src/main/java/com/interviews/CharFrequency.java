package com.interviews;

import java.util.*;
import java.util.stream.Collectors;

public class CharFrequency {
    public static void main(String[] args) {

        String str = "programming";
        Map<Character, Integer> map = new HashMap<>();

        for (char ch : str.toCharArray()) {
            map.put(ch, map.getOrDefault(ch, 0) + 1);
        }
        map.forEach((k, v) -> System.out.println(k + " : " + v));
    }

    static class Reverse {
        public static void main(String[] args) {
            String str = "programming";
            String rev = "";

            for (int i = str.length()-1; i>=0; i--) {
                rev = rev + str.charAt(i);
            }
            System.out.println("Reversed String : " + rev);
        }
    }
    static class CharacterFrequency {
        public static void main(String[] args) {
            String str = "reverse";
            Map<Character, Integer> freqMap = new HashMap<>();

            for (char ch : str.toCharArray()) {
                freqMap.put(ch, freqMap.getOrDefault(ch, 0) + 1);
            }
            freqMap.forEach((k, v) -> System.out.println(k + ":" + v));
        }
    }

    static class Maximin {
        public static void main(String[] args) {
            int arr[] = {12, 34, 56, 78, 33, 333, 22};
            int max = arr[0];

            for (int i=0; i<arr.length; i++) {
                if (arr[i] > max)
                    max = arr[i];
            }
            System.out.println("MAX: " + max);
        }
    }

    static class Minimum {
        public static void main(String[] args) {
            int arr[] = {12, 34, 2, 56, 77, 89};
            int min = arr[0];

            for (int i=0; i<arr.length; i++) {
                if (arr[i] < min)
                    min = arr[i];
            }
            System.out.println("MIN: " + min);
        }
    }

    static class SecondLargest {
        public static int secondLargestNumber(int arr[], int total) {
            int temp;

            for (int i=0; i<total; i++) {
                for (int j=i+1; j<total; j++) {
                    if (arr[i] > arr[j]) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 2];
        }

        public static void main(String[] args) {
            int arr[] = {12, 23, 45, 44, 22, 11};
            System.out.println("Second Largest Number: " + secondLargestNumber(arr, arr.length));
        }
    }

    static class SecondSmallest {
        public static int secondSmallestNumber(int arr[], int total) {
            int temp;

            for (int i=0; i<total; i++) {
                for (int j=i+1; j<total; j++) {
                    if (arr[i] < arr[j]) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 2];
        }

        public static void main(String[] args) {
            int arr[] = {11, 10, 33, 45, 67, 78, 89};
            System.out.println("Second Smallest Number: " + secondSmallestNumber(arr, arr.length));
        }
    }
    static class ThirdLargest {
        public static int thirdLargestNumber(int arr[], int total) {
            int temp;

            for (int i=0; i<total; i++) {
                for (int j=i+1; j<total; j++) {
                    if (arr[i] > arr[j]) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 3];
        }

        public static void main(String[] args) {
            int arr[] = {11, 10, 33, 45, 67, 78, 89};
            System.out.println("Third Largest Number: " + thirdLargestNumber(arr, arr.length));
        }
    }
    static class ThirdSmallestNumber {
        public static int thirdSmallestNumber(int arr[], int total) {
            int temp;

            for (int i=0; i<total; i++) {
                for (int j=i+1; j<total; j++) {
                    if (arr[i] < arr[j]) {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr[total - 3];
        }

        public static void main(String[] args) {
            int arr[] = {11, 10, 33, 45, 67, 78, 89};
            System.out.println("Third Smallest Number: " + thirdSmallestNumber(arr, arr.length));
        }
    }

    // comparator
    static class Employee {
        String name;
        int age;

        public Employee(String name, int age) {
            this.name = name;
            this.age = age;
        }

        @Override
        public String toString() {
            return "Employee{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    '}';
        }
    }
    static class TestEmployee {
        public static void main(String[] args) {
            List<Employee> employees = Arrays.asList(
                    new Employee("Pravendra", 27),
                    new Employee("Surendra", 28),
                    new Employee("Yogendra", 22),
                    new Employee("Hukam", 22),
                    new Employee("Durgesh", 17)
            );

            employees.sort(Comparator.comparingInt(e -> e.age));
            employees.forEach(System.out::println);
        }
    }

    // prime
    static class CheckPrime {
        public static boolean isPrime(int num) {
            if (num <= 1) return false;
            for (int i=2; i<Math.sqrt(num); i++) {
                if (num % i == 0) return false;
            }
            return true;
        }

        public static void main(String[] args) {
            int number = 29;
            System.out.println(number + " is Prime Number : " + isPrime(number));
        }
    }
    static class FilterEvenOdd {
        public static void main(String[] args) {
            List<Integer> numbers = Arrays.asList(10, 15, 20, 25, 30);

            List<Integer> even = numbers.stream().filter( n -> n % 2 == 0).collect(Collectors.toList());
            System.out.println("Even Number: " + even);

            List<Integer> odd = numbers.stream().filter(n -> n % 2 != 0).collect(Collectors.toList());
            System.out.println("Odd Number: " + odd);
        }
    }
    static class GroupingJava8 {
        public static void main(String[] args) {
            List<String> names = Arrays.asList("PK", "Tom", "Jerry", "Tom", "PK", "Spike", "Tom", "Jerry", "PK");

            Map<String, Long> nameCount = names.stream()
                    .collect(Collectors.groupingBy(name -> name, Collectors.counting()));
            nameCount.forEach((name, count) -> System.out.println(name + ":" + count));
        }
    }
}
