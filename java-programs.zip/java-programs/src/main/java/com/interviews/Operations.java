package com.interviews;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Operations {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David");

        // without stream api
        List<String> result = new ArrayList<>();
        for (String name : names) {
            if (name.startsWith("A")) {
                result.add(name);
            }
        }
        System.out.println("Without Stream : ");
        System.out.println(result);

        // with stream api
        List<String> stringList = names.stream()
                .filter(name -> name.startsWith("A"))
                .collect(Collectors.toList());
        System.out.println("With Stream : ");
        System.out.println(stringList);

        // sorted
        List<String> sort = names.stream()
                .filter(name -> name.startsWith("A"))
                .sorted()
                .limit(2)
                .collect(Collectors.toList());
        System.out.println("Sorted: ");
        System.out.println(sort);
    }
}
