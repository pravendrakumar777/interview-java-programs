package com.interviews;

public class MyService {

    public void m1() throws InterruptedException {
        Thread.sleep(1000);

        System.out.println("Method m1  executed");
    }
    public void m2() throws InterruptedException{
        Thread.sleep(5000);
        System.out.println("Method m2 executed");
    }

    public void m3() throws InterruptedException{
        Thread.sleep(6000);
        System.out.println("Method m3 executed");
    }
}
