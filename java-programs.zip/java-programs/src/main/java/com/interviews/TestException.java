package com.interviews;

public class TestException {
    public static void main(String[] args) throws InvalidAgeException {
        CustomException obj = new CustomException();
        obj.validateAge(16);
    }
}
