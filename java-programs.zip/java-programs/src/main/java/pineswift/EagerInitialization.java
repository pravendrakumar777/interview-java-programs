package pineswift;

public class EagerInitialization {
    private static final EagerInitialization instance = new EagerInitialization();
    private EagerInitialization() {}

    public static EagerInitialization getInstance() {
        return instance;
    }

    public static void main(String[] args) {
        EagerInitialization obj1 = EagerInitialization.getInstance();
        EagerInitialization obj2 = EagerInitialization.getInstance();

        System.out.println(obj1.hashCode());
        System.out.println(obj2.hashCode());
    }
}
