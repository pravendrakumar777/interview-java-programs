package pineswift;

public class LazyInitialization {
    public static LazyInitialization instance;
    private LazyInitialization() {}

    public static LazyInitialization getInstance() {
        if (instance == null) {
            instance = new LazyInitialization();
        }
        return instance;
    }

    public static void main(String[] args) {
        LazyInitialization obj1 = LazyInitialization.getInstance();
        LazyInitialization obj2 = LazyInitialization.getInstance();

        System.out.println(obj1.hashCode());
        System.out.println(obj2.hashCode());
    }
}
