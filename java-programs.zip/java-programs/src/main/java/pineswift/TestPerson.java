package pineswift;

import java.util.Arrays;
import java.util.List;

public class TestPerson {
    public static void main(String[] args) {
        List<Person> list = Arrays.asList(
                new Person("Pravendra", 30),
                new Person("Ajay", 25),
                new Person("Ramesh", 35),
                new Person("Devendra", 40)
        );

        // average age
        double averageAge = list.stream()
                .mapToInt(Person::getAge)
                .average().orElse(0);
        System.out.println("Average Age: " + averageAge);
    }
}
