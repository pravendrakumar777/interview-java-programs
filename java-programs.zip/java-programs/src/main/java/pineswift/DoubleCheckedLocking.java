package pineswift;

public class DoubleCheckedLocking {
    private static volatile DoubleCheckedLocking instance;
    private DoubleCheckedLocking() {}

    public static DoubleCheckedLocking getInstance() {
        if (instance == null) {
            synchronized (DoubleCheckedLocking.class) {
                if (instance == null) {
                    instance = new DoubleCheckedLocking();
                }
            }
        }
        return instance;
    }

    public static void main(String[] args) {
        DoubleCheckedLocking obj1 = DoubleCheckedLocking.getInstance();
        DoubleCheckedLocking obj2 = DoubleCheckedLocking.getInstance();
        DoubleCheckedLocking obj3 = DoubleCheckedLocking.getInstance();

        System.out.println(obj1.hashCode());
        System.out.println(obj2.hashCode());
        System.out.println(obj3.hashCode());
    }
}
