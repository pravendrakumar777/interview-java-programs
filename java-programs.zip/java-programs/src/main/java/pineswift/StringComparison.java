package pineswift;

public class StringComparison {
    public static void main(String[] args) {
        String str1 = "Sachin";
        String str2 = "Sachin";
        String str3 = new String("Sachin");

        System.out.println(str1==str2);    // true
        System.out.println(str1==str3);    // false
        System.out.println(str1.equals(str3)); // true
    }
}
