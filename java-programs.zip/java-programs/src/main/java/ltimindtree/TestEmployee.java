package ltimindtree;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class TestEmployee {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee("Alice", 70000),
                new Employee("Bob", 90000),
                new Employee("Charlie", 90000),
                new Employee("David", 85000)
        );

        OptionalDouble maxSalary = employees.stream().mapToDouble(Employee::getSalary).max();

        if (maxSalary.isPresent()) {
            List<String> maximum = employees.stream()
                    .filter(e -> e.getSalary() == maxSalary.getAsDouble())
                    .map(Employee::getName)
                    .collect(Collectors.toList());

            System.out.println("Highest Salary: " + maxSalary.getAsDouble());
            System.out.println("Employee(s) with highest salary: " + maximum);
        } else {
            System.out.println("No employees in the list.");
        }
    }
}
